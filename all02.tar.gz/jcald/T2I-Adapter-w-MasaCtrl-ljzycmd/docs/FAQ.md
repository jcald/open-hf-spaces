# FAQ

- **Q: The openpose adapter (t2iadapter_openpose_sd14v1) outputs gray-scale images.**

    **A:** You can add `colorful` in the prompt to avoid this problem.
