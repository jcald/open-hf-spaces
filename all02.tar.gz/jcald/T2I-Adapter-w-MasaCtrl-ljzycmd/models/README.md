You can manually download the models from
- [T2I-Adapter v1](https://huggingface.co/TencentARC/T2I-Adapter/tree/main/models)
- [CoAdapter Preview version](https://huggingface.co/TencentARC/T2I-Adapter/tree/main/models)
- [third-party-models](https://huggingface.co/TencentARC/T2I-Adapter/tree/main/third-party-models)

and put them into `models` folder 