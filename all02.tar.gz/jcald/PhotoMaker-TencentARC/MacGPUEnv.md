# How to use GPU on Mac M1/2

1. Install xcode tools

```
xcode-select --install
```

2. Install llvm

```
brew install llvm libomp
```

3. Install torch 2.1.2

```
pip install torch==2.1.2
```