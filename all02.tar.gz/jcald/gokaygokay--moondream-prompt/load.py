#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# vim: set fileencoding=utf-8 :
import platform
print(platform.python_version())
print("--------------------------------\n")

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from PIL import Image

DEVICE = "cuda"
DTYPE = torch.float32 if DEVICE == "cpu" else torch.float16  # CPU doesn't support float16
revision = "ac6c8fc0ba757c6c4d7d541fdd0e63618457350c"
tokenizer = AutoTokenizer.from_pretrained("gokaygokay/moondream-prompt", revision=revision)
moondream = AutoModelForCausalLM.from_pretrained(
    "gokaygokay/moondream-prompt",
    trust_remote_code=True,
    torch_dtype=DTYPE,
    device_map={"": DEVICE},
    revision=revision
)
moondream.eval()

image_path = "gatoLat01.png"
image = Image.open(image_path).convert("RGB")

# Aquí se tokeniza la pregunta para determinar el seq_len
question = "Describe this image and its style in a very detailed manner"
input_ids = tokenizer.encode(question, return_tensors="pt").to(DEVICE)
seq_len = input_ids.size(1)  # Obtenemos la longitud de la secuencia

position_ids = torch.arange(0, seq_len, dtype=torch.long, device=DEVICE)

md_answer = moondream.answer_question(
    moondream.encode_image(image),
    question,
    tokenizer=tokenizer,
    position_ids=position_ids,  # Asegúrate de que la función use estos position_ids
)

print(md_answer)
