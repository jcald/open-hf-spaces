#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# vim: set fileencoding=utf-8 :
import platform
print(platform.python_version())
print("--------------------------------\n")

import torch
from diffusers import DiffusionPipeline, DPMSolverMultistepScheduler
from diffusers.utils import export_to_video
import numpy as np

pipe = DiffusionPipeline.from_pretrained("damo-vilab/text-to-video-ms-1.7b", torch_dtype=torch.float16, variant="fp16")
pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config)
pipe.enable_model_cpu_offload()

prompt = "Spiderman is surfing"
video_frames = pipe(prompt, num_inference_steps=25).frames
#video_path = export_to_video(video_frames, mode='RGB')
#video_path = export_to_video(video_frames)
# Convertir cada frame a RGB si no lo está ya
rgb_frames = []
for frame in video_frames:
    if frame.shape[-1] == 1:  # Si es escala de grises
        rgb_frame = np.repeat(frame, 3, axis=-1)
    elif frame.shape[-1] == 2:  # Si es escala de grises con alfa
        rgb_frame = np.repeat(frame[..., :1], 3, axis=-1)  # Ignorar alfa
    elif frame.shape[-1] == 3:  # Si ya es RGB
        rgb_frame = frame
    elif frame.shape[-1] == 4:  # Si es RGBA
        rgb_frame = frame[..., :3]  # Ignorar alfa
    else:
        raise ValueError(f"Unexpected number of channels: {frame.shape[-1]}")

video_path = export_to_video(rgb_frames)
