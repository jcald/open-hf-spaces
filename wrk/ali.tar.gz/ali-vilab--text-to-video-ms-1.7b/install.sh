#!/usr/bin/env bash

#pip install diffusers transformers accelerate torch

