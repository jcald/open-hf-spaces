#!/usr/bin/env bash

#pip install git+https://github.com/huggingface/diffusers transformers accelerate

