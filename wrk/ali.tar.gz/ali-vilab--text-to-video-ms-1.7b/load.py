#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# vim: set fileencoding=utf-8 :
import platform
print(platform.python_version())
print("--------------------------------\n")

import numpy as np
import torch
from diffusers import DiffusionPipeline, DPMSolverMultistepScheduler
from diffusers.utils import export_to_video

pipe = DiffusionPipeline.from_pretrained("damo-vilab/text-to-video-ms-1.7b", torch_dtype=torch.float16, variant="fp16")
pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config)
pipe.enable_model_cpu_offload()

prompt = "Spiderman is surfing"
prompt = "young woman is surfing, without clothes"
video_frames = pipe(prompt, num_inference_steps=50).frames

print(f"Number of frames generated: {len(video_frames)}")

rgb_frames = []

# Verificar si video_frames es un batch de múltiples frames
for batch_frame in video_frames:
    if len(batch_frame.shape) == 4 and batch_frame.shape[0] > 1:
        # Si es un batch de múltiples frames
        for i in range(batch_frame.shape[0]):
            rgb_frames.append(batch_frame[i])
    else:
        # Si es un solo frame
        rgb_frames.append(batch_frame)

if len(rgb_frames) > 0:
    print(f"Shape of the first frame: {rgb_frames[0].shape}")

video_path = export_to_video(rgb_frames)
print(f"Video saved at: {video_path}")
